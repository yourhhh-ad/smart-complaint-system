export const UI = {
  initTheme() {
    const isDark = localStorage.getItem('antigravity_theme') === 'dark';
    if (isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    
    const themeBtn = document.getElementById('themeToggle');
    if (themeBtn) {
      themeBtn.addEventListener('click', () => {
        document.documentElement.classList.toggle('dark');
        localStorage.setItem('antigravity_theme', document.documentElement.classList.contains('dark') ? 'dark' : 'light');
      });
    }
  },

  showToast(message, type = 'info') {
    let container = document.getElementById('toast-container');
    if (!container) {
      container = document.createElement('div');
      container.id = 'toast-container';
      document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    
    let icon = '';
    if (type === 'success') icon = '<i data-lucide="check-circle" class="w-5 h-5 text-green-500"></i>';
    else if (type === 'error') icon = '<i data-lucide="alert-circle" class="w-5 h-5 text-red-500"></i>';
    else icon = '<i data-lucide="info" class="w-5 h-5 text-blue-500"></i>';

    toast.innerHTML = `${icon} <span>${message}</span>`;
    container.appendChild(toast);
    
    if (window.lucide) {
      window.lucide.createIcons();
    }

    setTimeout(() => {
      toast.classList.add('fade-out');
      setTimeout(() => toast.remove(), 300);
    }, 3000);
  },

  animateCounters() {
    const counters = document.querySelectorAll('.counter-anim');
    counters.forEach(counter => {
      const target = +counter.getAttribute('data-target');
      const duration = 1000;
      const step = target / (duration / 16); // 60fps
      
      let current = 0;
      const updateCounter = () => {
        current += step;
        if (current < target) {
          counter.innerText = Math.ceil(current);
          requestAnimationFrame(updateCounter);
        } else {
          counter.innerText = target;
        }
      };
      updateCounter();
    });
  },

  injectSidebar(activePath) {
    const sidebarHTML = `
      <aside id="sidebar" class="fixed inset-y-0 left-0 w-64 glass z-40 transform -translate-x-full lg:translate-x-0 transition-transform duration-300 flex flex-col border-r border-border-light dark:border-border-dark">
        <div class="p-6 flex items-center justify-between">
          <a href="../index.html" class="flex items-center gap-2">
            <i data-lucide="shield" class="w-8 h-8 text-indigo-600 dark:text-indigo-400"></i>
            <span class="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-indigo-600 to-pink-500">SafeCampus</span>
          </a>
          <button id="closeSidebar" class="lg:hidden text-text-muted-light dark:text-text-muted-dark">
            <i data-lucide="x" class="w-6 h-6"></i>
          </button>
        </div>
        
        <nav class="flex-1 px-4 py-4 space-y-1 overflow-y-auto">
          <div class="text-xs font-semibold text-text-muted-light dark:text-text-muted-dark uppercase tracking-wider mb-2 mt-4 px-2">Student Area</div>
          <a href="student-dashboard.html" class="flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${activePath === 'student-dashboard' ? 'bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400 font-medium' : 'text-text-light dark:text-text-dark hover:bg-slate-100 dark:hover:bg-slate-800'}">
            <i data-lucide="layout-dashboard" class="w-5 h-5"></i> Dashboard
          </a>
          <a href="register-complaint.html" class="flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${activePath === 'register-complaint' ? 'bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400 font-medium' : 'text-text-light dark:text-text-dark hover:bg-slate-100 dark:hover:bg-slate-800'}">
            <i data-lucide="file-plus" class="w-5 h-5"></i> File Complaint
          </a>
          <a href="track-complaint.html" class="flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${activePath === 'track-complaint' ? 'bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400 font-medium' : 'text-text-light dark:text-text-dark hover:bg-slate-100 dark:hover:bg-slate-800'}">
            <i data-lucide="map-pin" class="w-5 h-5"></i> Track Status
          </a>
          <a href="complaint-history.html" class="flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${activePath === 'complaint-history' ? 'bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400 font-medium' : 'text-text-light dark:text-text-dark hover:bg-slate-100 dark:hover:bg-slate-800'}">
            <i data-lucide="history" class="w-5 h-5"></i> History
          </a>

          <div class="text-xs font-semibold text-text-muted-light dark:text-text-muted-dark uppercase tracking-wider mb-2 mt-8 px-2">Administration</div>
          <a href="admin-dashboard.html" class="flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${activePath === 'admin-dashboard' ? 'bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400 font-medium' : 'text-text-light dark:text-text-dark hover:bg-slate-100 dark:hover:bg-slate-800'}">
            <i data-lucide="shield-alert" class="w-5 h-5"></i> Admin Dashboard
          </a>
          <a href="reports.html" class="flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${activePath === 'reports' ? 'bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400 font-medium' : 'text-text-light dark:text-text-dark hover:bg-slate-100 dark:hover:bg-slate-800'}">
            <i data-lucide="pie-chart" class="w-5 h-5"></i> Reports
          </a>
          <a href="settings.html" class="flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${activePath === 'settings' ? 'bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400 font-medium' : 'text-text-light dark:text-text-dark hover:bg-slate-100 dark:hover:bg-slate-800'}">
            <i data-lucide="settings" class="w-5 h-5"></i> Settings
          </a>
        </nav>
        
        <div class="p-4 border-t border-border-light dark:border-border-dark">
          <div class="flex items-center gap-3 px-3 py-2">
            <div class="w-8 h-8 rounded-full bg-indigo-100 dark:bg-indigo-900 flex items-center justify-center text-indigo-600 dark:text-indigo-400 font-bold">
              U
            </div>
            <div class="flex-1 overflow-hidden">
              <p class="text-sm font-medium truncate">User Profile</p>
              <p class="text-xs text-text-muted-light dark:text-text-muted-dark truncate">demo@student.edu</p>
            </div>
          </div>
        </div>
      </aside>
      
      <!-- Mobile overlay -->
      <div id="sidebarOverlay" class="fixed inset-0 bg-black/50 z-30 hidden lg:hidden backdrop-blur-sm"></div>
    `;

    document.body.insertAdjacentHTML('afterbegin', sidebarHTML);

    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    const openBtn = document.getElementById('openSidebar');
    const closeBtn = document.getElementById('closeSidebar');

    const toggleSidebar = () => {
      sidebar.classList.toggle('-translate-x-full');
      overlay.classList.toggle('hidden');
    };

    if (openBtn) openBtn.addEventListener('click', toggleSidebar);
    if (closeBtn) closeBtn.addEventListener('click', toggleSidebar);
    if (overlay) overlay.addEventListener('click', toggleSidebar);
    
    if (window.lucide) {
      window.lucide.createIcons();
    }
  },

  injectNavbar(title) {
    const navbarHTML = `
      <header class="h-16 glass border-b border-border-light dark:border-border-dark sticky top-0 z-20 flex items-center justify-between px-4 lg:px-8">
        <div class="flex items-center gap-4">
          <button id="openSidebar" class="lg:hidden text-text-muted-light dark:text-text-muted-dark hover:text-text-light dark:hover:text-text-dark">
            <i data-lucide="menu" class="w-6 h-6"></i>
          </button>
          <h1 class="text-xl font-semibold">${title}</h1>
        </div>
        <div class="flex items-center gap-4">
          <button id="themeToggle" class="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
            <i data-lucide="moon" class="w-5 h-5 hidden dark:block"></i>
            <i data-lucide="sun" class="w-5 h-5 block dark:hidden"></i>
          </button>
          <button class="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors relative">
            <i data-lucide="bell" class="w-5 h-5"></i>
            <span class="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
          </button>
        </div>
      </header>
    `;

    const mainContent = document.querySelector('main');
    if (mainContent) {
      mainContent.insertAdjacentHTML('beforebegin', navbarHTML);
    }
    
    // Re-bind theme toggle since we injected a new one
    this.initTheme();
  },
  
  getBadgeColorClass(value, type) {
    if (type === 'status') {
      switch(value) {
        case 'Resolved': return 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400';
        case 'Pending': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400';
        case 'Under Investigation': return 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400';
        default: return 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300';
      }
    } else if (type === 'priority' || type === 'severity') {
      switch(value) {
        case 'Critical': return 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400';
        case 'High': return 'bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-400';
        case 'Moderate':
        case 'Medium': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400';
        case 'Low': return 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400';
        default: return 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300';
      }
    }
    return '';
  }
};
