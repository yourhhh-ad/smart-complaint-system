export const AIEngine = {
  analyzeComplaint(text) {
    return new Promise((resolve) => {
      // Simulate network delay
      setTimeout(() => {
        const lowerText = text.toLowerCase();
        let result = {
          category: 'General Grievance',
          priority: 'Low',
          severity: 'Low',
          department: 'Student Welfare Cell',
          sentiment: 'Neutral',
          confidence: 85,
          keywords: [],
          recommendation: 'Monitor situation and follow up if escalates.'
        };

        const physicalKeywords = ['threat', 'senior', 'hostel', 'physical', 'force', 'cleaning', 'chores', 'beating', 'slap', 'hit'];
        const cyberKeywords = ['fake', 'social media', 'online', 'harassment', 'cyber', 'messages', 'instagram', 'facebook', 'whatsapp', 'troll'];
        const verbalKeywords = ['abuse', 'verbal', 'slurs', 'calling names', 'mocking', 'shouting', 'insulting'];
        const psychKeywords = ['isolation', 'exclusion', 'bullying', 'ignoring', 'mental', 'stress', 'depression'];

        const hasMatches = (keywords) => keywords.filter(k => lowerText.includes(k));

        const physMatches = hasMatches(physicalKeywords);
        const cyberMatches = hasMatches(cyberKeywords);
        const verbMatches = hasMatches(verbalKeywords);
        const psychMatches = hasMatches(psychKeywords);

        const maxMatches = Math.max(physMatches.length, cyberMatches.length, verbMatches.length, psychMatches.length);

        if (maxMatches > 0) {
          if (maxMatches === physMatches.length) {
            result = {
              category: 'Physical Ragging',
              priority: 'High',
              severity: 'Critical',
              department: 'Anti-Ragging Committee',
              sentiment: 'Negative',
              confidence: Math.min(99, 85 + (physMatches.length * 5)),
              keywords: physMatches,
              recommendation: 'Immediate intervention required. Dispatch hostel warden and notify Anti-Ragging squad.'
            };
          } else if (maxMatches === cyberMatches.length) {
            result = {
              category: 'Cyber Ragging',
              priority: 'High',
              severity: 'High',
              department: 'Cyber Cell',
              sentiment: 'Negative',
              confidence: Math.min(99, 85 + (cyberMatches.length * 5)),
              keywords: cyberMatches,
              recommendation: 'Preserve digital evidence. Initiate IT trace and flag for Cyber Cell review.'
            };
          } else if (maxMatches === verbMatches.length) {
            result = {
              category: 'Verbal Ragging',
              priority: 'Medium',
              severity: 'Moderate',
              department: 'Anti-Ragging Committee',
              sentiment: 'Negative',
              confidence: Math.min(99, 85 + (verbMatches.length * 5)),
              keywords: verbMatches,
              recommendation: 'Schedule mediation session. Issue formal warning to perpetrators.'
            };
          } else if (maxMatches === psychMatches.length) {
            result = {
              category: 'Psychological Ragging',
              priority: 'Medium',
              severity: 'Moderate',
              department: 'Student Welfare Cell',
              sentiment: 'Negative',
              confidence: Math.min(99, 85 + (psychMatches.length * 5)),
              keywords: psychMatches,
              recommendation: 'Arrange counseling session for victim. Investigate group dynamics.'
            };
          }
        }

        resolve(result);
      }, 1500); // 1.5s delay
    });
  }
};
