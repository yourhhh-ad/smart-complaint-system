const STORAGE_KEY = 'antigravity_complaints_db';

const MOCK_SEED_DATA = [
  {
    id: 'CMP-2023-1001',
    title: 'Forced cleaning of senior hostel rooms',
    description: 'Seniors from the 3rd year forced me and my roommates to clean their rooms and wash their clothes under threat of physical beating if we refused.',
    category: 'Physical Ragging',
    priority: 'High',
    severity: 'Critical',
    department: 'Anti-Ragging Committee',
    status: 'Resolved',
    dateSubmitted: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
    studentName: 'John Doe',
    studentId: 'CS2023001',
    anonymous: false,
    historyLog: [
      { date: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(), action: 'Complaint Submitted' },
      { date: new Date(Date.now() - 29 * 24 * 60 * 60 * 1000).toISOString(), action: 'AI Analysis Completed' },
      { date: new Date(Date.now() - 28 * 24 * 60 * 60 * 1000).toISOString(), action: 'Assigned to Anti-Ragging Committee' },
      { date: new Date(Date.now() - 25 * 24 * 60 * 60 * 1000).toISOString(), action: 'Investigation Started' },
      { date: new Date(Date.now() - 20 * 24 * 60 * 60 * 1000).toISOString(), action: 'Resolved - Disciplinary action taken' }
    ]
  },
  {
    id: 'CMP-2023-1002',
    title: 'Fake Instagram account and online harassment',
    description: 'Someone created a fake profile with my photos and is sending abusive messages to my classmates. I suspect it is my seniors as they were mocking me about this yesterday.',
    category: 'Cyber Ragging',
    priority: 'High',
    severity: 'High',
    department: 'Cyber Cell',
    status: 'Under Investigation',
    dateSubmitted: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
    studentName: 'Jane Smith',
    studentId: 'EC2023045',
    anonymous: false,
    historyLog: [
      { date: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(), action: 'Complaint Submitted' },
      { date: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000).toISOString(), action: 'Assigned to Cyber Cell' },
      { date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(), action: 'Investigation Started' }
    ]
  },
  {
    id: 'CMP-2023-1003',
    title: 'Daily verbal abuse by classmates',
    description: 'A group of classmates continuously uses slurs, verbal abuse, and calls me derogatory names during breaks. It is affecting my mental health.',
    category: 'Verbal Ragging',
    priority: 'Medium',
    severity: 'Moderate',
    department: 'Anti-Ragging Committee',
    status: 'Pending',
    dateSubmitted: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    studentName: 'Anonymous',
    studentId: 'Anonymous',
    anonymous: true,
    historyLog: [
      { date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(), action: 'Complaint Submitted' }
    ]
  },
  {
    id: 'CMP-2023-1004',
    title: 'Exclusion and isolation in group projects',
    description: 'I am being deliberately ignored and isolated by my seniors in the lab. They exclude me from all activities and bully me into doing all the documentation work alone.',
    category: 'Psychological Ragging',
    priority: 'Medium',
    severity: 'Moderate',
    department: 'Student Welfare Cell',
    status: 'Resolved',
    dateSubmitted: new Date(Date.now() - 60 * 24 * 60 * 60 * 1000).toISOString(),
    studentName: 'Alice Johnson',
    studentId: 'ME2022012',
    anonymous: false,
    historyLog: [
      { date: new Date(Date.now() - 60 * 24 * 60 * 60 * 1000).toISOString(), action: 'Complaint Submitted' },
      { date: new Date(Date.now() - 55 * 24 * 60 * 60 * 1000).toISOString(), action: 'Resolved via mediation' }
    ]
  },
  {
    id: 'CMP-2023-1005',
    title: 'Threats from seniors outside campus',
    description: 'Seniors threatened to use physical force if I did not pay for their meals at the local cafe. They said they would beat me up in the hostel.',
    category: 'Physical Ragging',
    priority: 'High',
    severity: 'Critical',
    department: 'Anti-Ragging Committee',
    status: 'Pending',
    dateSubmitted: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
    studentName: 'Anonymous',
    studentId: 'Anonymous',
    anonymous: true,
    historyLog: [
      { date: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(), action: 'Complaint Submitted' }
    ]
  }
];

export const DB = {
  init() {
    if (!localStorage.getItem(STORAGE_KEY)) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(MOCK_SEED_DATA));
    }
  },

  getAll() {
    this.init();
    return JSON.parse(localStorage.getItem(STORAGE_KEY));
  },

  getById(id) {
    const data = this.getAll();
    return data.find(c => c.id === id);
  },

  save(complaint) {
    const data = this.getAll();
    // Generate ID if not present
    if (!complaint.id) {
      const year = new Date().getFullYear();
      const randomNum = Math.floor(1000 + Math.random() * 9000);
      complaint.id = `CMP-${year}-${randomNum}`;
      complaint.dateSubmitted = new Date().toISOString();
      complaint.status = 'Pending';
      complaint.historyLog = [
        { date: new Date().toISOString(), action: 'Complaint Submitted' },
        { date: new Date().toISOString(), action: 'AI Analysis Completed' }
      ];
      data.push(complaint);
    } else {
      const index = data.findIndex(c => c.id === complaint.id);
      if (index !== -1) {
        data[index] = { ...data[index], ...complaint };
      }
    }
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    return complaint;
  },

  updateStatus(id, newStatus, message = '') {
    const data = this.getAll();
    const index = data.findIndex(c => c.id === id);
    if (index !== -1) {
      data[index].status = newStatus;
      data[index].historyLog.push({
        date: new Date().toISOString(),
        action: `Status updated to ${newStatus}${message ? ` - ${message}` : ''}`
      });
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
      return data[index];
    }
    return null;
  },
  
  getStats() {
    const data = this.getAll();
    return {
      total: data.length,
      pending: data.filter(c => c.status === 'Pending').length,
      investigating: data.filter(c => c.status === 'Under Investigation').length,
      resolved: data.filter(c => c.status === 'Resolved').length,
      highPriority: data.filter(c => c.priority === 'High').length,
      critical: data.filter(c => c.severity === 'Critical').length,
      anonymous: data.filter(c => c.anonymous).length
    };
  }
};
