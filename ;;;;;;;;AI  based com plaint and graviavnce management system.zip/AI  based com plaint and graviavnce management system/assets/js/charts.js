export const Charts = {
  renderDoughnut(ctxId, data, labels, colors) {
    const ctx = document.getElementById(ctxId);
    if (!ctx) return null;
    
    return new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels: labels,
        datasets: [{
          data: data,
          backgroundColor: colors,
          borderWidth: 0,
          hoverOffset: 4
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'bottom',
            labels: {
              color: document.documentElement.classList.contains('dark') ? '#f8fafc' : '#0f172a'
            }
          }
        },
        cutout: '70%'
      }
    });
  },

  renderBar(ctxId, data, labels, colors, label = 'Count') {
    const ctx = document.getElementById(ctxId);
    if (!ctx) return null;

    const textColor = document.documentElement.classList.contains('dark') ? '#f8fafc' : '#0f172a';
    const gridColor = document.documentElement.classList.contains('dark') ? '#334155' : '#e2e8f0';

    return new Chart(ctx, {
      type: 'bar',
      data: {
        labels: labels,
        datasets: [{
          label: label,
          data: data,
          backgroundColor: colors,
          borderRadius: 4
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          y: {
            beginAtZero: true,
            ticks: { stepSize: 1, color: textColor },
            grid: { color: gridColor }
          },
          x: {
            ticks: { color: textColor },
            grid: { display: false }
          }
        },
        plugins: {
          legend: { display: false }
        }
      }
    });
  },
  
  renderLine(ctxId, datasets, labels) {
    const ctx = document.getElementById(ctxId);
    if (!ctx) return null;
    
    const textColor = document.documentElement.classList.contains('dark') ? '#f8fafc' : '#0f172a';
    const gridColor = document.documentElement.classList.contains('dark') ? '#334155' : '#e2e8f0';

    return new Chart(ctx, {
      type: 'line',
      data: {
        labels: labels,
        datasets: datasets
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          y: {
            beginAtZero: true,
            ticks: { stepSize: 1, color: textColor },
            grid: { color: gridColor }
          },
          x: {
            ticks: { color: textColor },
            grid: { display: false }
          }
        },
        plugins: {
          legend: {
            position: 'top',
            labels: { color: textColor }
          }
        },
        interaction: {
          mode: 'index',
          intersect: false,
        },
      }
    });
  }
};
